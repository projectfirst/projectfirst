require "Landmark"
require "Flipkart"
require "Pricesbolo"
require "Pricegrabber"
class ParsevendorController < ApplicationController
  
  def search
    if params[:query]
    landmark = Landmark.new(params[:query])
    @resultlandmark=landmark.getResult
    flipkart = Flipkart.new(params[:query])
    @resultflipkart=flipkart.getResult
    pricesbolo = Pricesbolo.new(params[:query])
    @resultpricesbolo=pricesbolo.getResult
    pricegrabber = Pricegrabber.new(params[:query])
    @resultpricegrabber=pricegrabber.getResult

    else
    puts "got into the else of search method..DANGER!!!"
    end
  end
   

end

