tries = 0
begin
  UserMailer.activation(@user).deliver
rescue Errono::ECONNRESET => e
  if (tries += 1) > 2
    retry
  else
   # log error
  end
end

