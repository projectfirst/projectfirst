require "GenericVendor"
class Flipkart

  def initialize(keyword)
    @keyword = keyword
    puts "starting.."
    obj = GenericVendor.new("http://www.flipkart.com/search/a/books?query=KEYWORD","Flpkart",@keyword);
    puts "created object with params.."
    obj.setPattern("h2[@class='fk-srch-item-title fksd-bodytext']/a");
    puts "pattern is set...."
    obj.createUrl
    puts "End url is created..."
    obj.search
    puts "search complete..."
    obj.print
    puts "printed results..!"
    @final=obj.giveResult
  end

  def getResult
    @final
  end

end
