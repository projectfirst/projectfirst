require 'rubygems'
require 'hpricot'
require 'open-uri'


class  GenericVendor

  def initialize(url, vendorName, keyWord)
    @url = url
    @vendorName = vendorName
    @keyWord = keyWord
  end

  def setPattern(pattern)
    @pattern=pattern
  end
  
  def createUrl
    puts "Creating the end url..."
    @midUrl = @url.gsub(/KEYWORD/, @keyWord) 
    @endUrl = @midUrl.gsub(/\s/,"+")
    puts "The end url is created as"  + @endUrl
  end
  def search
    puts "begin search for the URL " + @endUrl
    @htmlFile = Hpricot(open(@endUrl))
    puts "Hpricot grabbed the webpage into htmlfile-a instance variable......"
    @resultSet=Array.new
    puts "array created to store the parsed htmlfile.."
    @htmlFile.search(@pattern).each do |loopProducts|
    @resultSet << loopProducts.inner_html
    end
    puts "end of search..."
  end

  def print
    puts @resultSet
  end
  def giveResult
     @resultSet
  end

end
