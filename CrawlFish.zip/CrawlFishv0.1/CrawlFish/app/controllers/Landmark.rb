require "GenericVendor"
class Landmark

  def initialize(keyword)
    @keyword = keyword
    puts "starting.."
    obj = GenericVendor.new("http://www.landmarkonthenet.com/product/SearchPaging.aspx?code=KEYWORD&type=0&num=0","Landmark",@keyword);
    puts "created object with params.."
    obj.setPattern("div[@class='searc_box_cen']//a");
    puts "pattern is set...."
    obj.createUrl
    puts "End url is created..."
    obj.search
    puts "search complete..."
    obj.print
    puts "printed results..!"
    @final=obj.giveResult
  end
 
  def getResult
    @final
  end 
end
