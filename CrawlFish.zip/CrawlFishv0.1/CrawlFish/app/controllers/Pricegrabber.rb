require "GenericVendor"
class Pricegrabber

  def initialize(keyword)
    @keyword = keyword
    puts "starting.."
    obj = GenericVendor.new("http://computers.pricegrabber.com/KEYWORD/p/13/form_keyword=KEYWORD","Landmark",@keyword);
    puts "created object with params.."
    obj.setPattern("div[@class='item_details']/h3/a");
    puts "pattern is set...."
    obj.createUrl
    puts "End url is created..."
    obj.search
    puts "search complete..."
    obj.print
    puts "printed results..!"
    @final=obj.giveResult
  end
 
  def getResult
    @final
  end 
end
