require "GenericVendor"
class Pricesbolo

  def initialize(keyword)
    @keyword = keyword
    puts "starting.."
    obj = GenericVendor.new("http://www.pricesbolo.com/WebUI/TextSearchResults.aspx?ST=KEYWORD","Pricesbolo",@keyword);
    puts "created object with params.."
    obj.setPattern("div[@class='dtls']/h5/a");
    puts "pattern is set...."
    obj.createUrl
    puts "End url is created..."
    obj.search
    puts "search complete..."
    obj.print
    puts "printed results..!"
    @final=obj.giveResult
  end
 
  def getResult
    @final
  end 
end
