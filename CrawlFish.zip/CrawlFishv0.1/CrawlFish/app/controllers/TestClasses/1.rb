require 'rubygems'
require 'hpricot'
require 'open-uri'

@url = 'http://computers.pricegrabber.com/laptop/p/13/form_keyword=laptop'
  hp = Hpricot(open(@url))
pars = Array.new
hp.search("div[@class='item_details']/h3/a").each  do |p|
pars << p.inner_html
end
puts pars
