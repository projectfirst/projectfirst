require "IMDB"
class ImdbController < ApplicationController

 def start
	imdb = IMDB.new('http://imdb.com/title/tt0335266/')

	@rating =  imdb.rating
	@title =  imdb.title
	@info =  imdb.extrainfo

 end
end
