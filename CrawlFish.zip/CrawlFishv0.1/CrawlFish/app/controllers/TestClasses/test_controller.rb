class TestController < ApplicationController
  def testview
  cmd = "perl /home/www/cgi-bin/test.pl"
        output = `#{cmd}`

        if( output == nil )
                @missing = "missing is NIL"
        else
                @missing =  "[#{output}]"
	end

  end

end
