require "Landmark"
require "Flipkart"
require "Pricesbolo"
require "Pricegrabber"
class ParsevendorController < ApplicationController

 def func1
  if params[:query]
    landmark = Landmark.new(params[:query])
    @resultlandmark=landmark.getResult
  else
    puts "got into the else of search method..DANGER!!!"
    end
 end

 def func2
  if params[:query]
    flipkart = Flipkart.new(params[:query])
    @resultflipkart=flipkart.getResult
  else
    puts "got into the else of search method..DANGER!!!"
  end
 end

 def func3
  if params[:query]
    pricesbolo = Pricesbolo.new(params[:query])
    @resultpricesbolo=pricesbolo.getResult
  else
    puts "got into the else of search method..DANGER!!!"
  end
 end
 
 def func4
  if params[:query]
    pricegrabber = Pricegrabber.new(params[:query])
    @resultpricegrabber=pricegrabber.getResult

    else
    puts "got into the else of search method..DANGER!!!"
    end
  end

  
  def search

   t1=Thread.new{func1()}
   t2=Thread.new{func2()}
   t3=Thread.new{func3()}
   t4=Thread.new{func4()}
   t1.join
   t2.join
   t3.join
   t4.join

  end
   

end

