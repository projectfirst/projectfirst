a="apple is god"
puts a
c="replaced"
b= a.gsub(/god/,c)
puts b
