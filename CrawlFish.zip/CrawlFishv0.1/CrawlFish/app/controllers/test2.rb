require "Landmark"
require "Flipkart"
class ParsevendorController 
  
  def initialize
    
    landmark = Landmark.new("jesus")
    @resultlandmark=landmark.getResult
    flipkart = Flipkart.new("jesus")
    @resultflipkart=flipkart.getResult
  end
  def getflip
   @resultflipkart
  end   

end
p= ParsevendorController.new
@r=p.getflip
for i in @r
puts "#{i}"
end
