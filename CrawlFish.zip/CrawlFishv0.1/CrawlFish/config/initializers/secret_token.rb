# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CrawlFish::Application.config.secret_token = 'f6708f900dd8a2b3ac4f508666c1a4b3da2a8d24434649e72fd365501d024ac319c67716fda043bf2608603aceb30dd97af0f82bc5c379e66c5b9b17ed589b3a'
