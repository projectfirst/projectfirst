require 'IMDB'


imdb = IMDB.new('http://imdb.com/title/tt0335266/')

p imdb.rating
p imdb.title
p imdb.extrainfo
