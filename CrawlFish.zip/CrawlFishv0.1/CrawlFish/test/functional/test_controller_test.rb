require 'test_helper'

class TestControllerTest < ActionController::TestCase
  test "should get testview" do
    get :testview
    assert_response :success
  end

end
