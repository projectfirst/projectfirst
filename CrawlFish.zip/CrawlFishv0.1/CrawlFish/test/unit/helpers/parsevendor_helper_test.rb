require 'test_helper'

class ParsevendorHelperTest < ActionView::TestCase
end
